#!/usr/bin/python
# -*- coding: utf-8 -*-

# Convierte temperaturas
# www.pythondiario.com

import sys
from PyQt4 import QtCore, QtGui, uic
import cv2
from PyQt4.QtGui import *
import time
from pylepton.Lepton3 import Lepton3
import numpy as np
import sys

# Cargar nuestro archivo .ui
form_class = uic.loadUiType("footshot.ui")[0]


class MyWindowClass(QtGui.QMainWindow, form_class):
    def __init__(self, parent=None):
        QtGui.QMainWindow.__init__(self, parent)
        self.setupUi(self)
        self.status = True
        self.pushButton.clicked.connect(self.play)
        self.pushButton_2.clicked.connect(self.stop)
        self.pushButton.setStyleSheet("background-color: green")
        self.pushButton_2.setStyleSheet("background-color: red")


        # Configuracion de Grafico
        #self.graph = self.graphicsView
        #self.graph.setLabel("left", "Cuentas", units="count")
        #self.graph.setLabel("bottom", "Longitud de Onda", units="um")
        #self.graph.setScale(1)
        #self.graph.setXRange(200, 1000)
        #self.graph.setLimits(xMin=200, xMax=1000, minXRange=100, maxXRange=100)
        #self.graph.setBackground('w')

    def capture(flip_v=True, device="/dev/spidev0.0"):
        with Lepton3(device) as l:
            a, _ = l.capture()
        if flip_v:
            cv2.flip(a, 0, a)
        cv2.normalize(a, a, 0, 65535, cv2.NORM_MINMAX)

        ## Overlay ##

        cv2.circle(a, (80, 60), 20, (255, 0, 255))
        ##
        np.right_shift(a, 8, a)
        return np.uint8(a)

    def Adq(self):
        self.pushButton.setText('Adquiriendo')
        cvImg = self.capture()
        qImg = QImage(cvImg, 160, 120, QtGui.QImage.Format_Indexed8)
        self.label.setPixmap(QtGui.QPixmap.fromImage(qImg).scaled(qImg.width() * 2, qImg.height() * 2))
        #self.graph.plot(cvImg, clear=True)



    def stop(self):
        self.pushButton.setText('play')
        self.status = False
        self.timer.stop()
        cv2.destroyAllWindows()

    def play(self):
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.Adq)
        self.timer.start(1000. / 50)


app = QtGui.QApplication(sys.argv)
MyWindow = MyWindowClass(None)
MyWindow.show()
app.exec_()
