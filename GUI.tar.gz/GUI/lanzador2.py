#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
from PyQt4 import QtCore, QtGui, uic
import cv2
from PyQt4.QtGui import *
import time
from pylepton.Lepton3 import Lepton3
import numpy as np
import sys
import os
from libtiff import TIFF, TIFFimage
import datetime

# Cargar nuestro archivo .ui
form_class = uic.loadUiType("footshot.ui")[0]

i = 0
cvImg = None


class MyWindowClass(QtGui.QMainWindow, form_class):
    def __init__(self, parent=None):
        QtGui.QMainWindow.__init__(self, parent)
        self.setupUi(self)
        self.status = True
        self.pushButton.clicked.connect(self.play)
        self.pushButton_2.clicked.connect(self.stop)

        self.pushButton_3.setCheckable(True)
        self.pushButton_3.clicked[bool].connect(self.RecStop)

        #self.pushButton_3.clicked.connect(self.Rec)
        self.pushButton.setStyleSheet("background-color: green")
        self.pushButton_2.setStyleSheet("background-color: red")


        # Configuracion de Grafico
        # self.graph = self.graphicsView
        # self.graph.setLabel("left", "Cuentas", units="count")
        # self.graph.setLabel("bottom", "Longitud de Onda", units="um")
        # self.graph.setScale(1)
        # self.graph.setXRange(200, 1000)
        # self.graph.setLimits(xMin=200, xMax=1000, minXRange=100, maxXRange=100)
        # self.graph.setBackground('w')

    def capture(flip_v = False, device="/dev/spidev0.0"):
        with Lepton3(device) as l:
            a, _ = l.capture()
        if flip_v:
            cv2.flip(a, 0, a)
        cv2.normalize(a, a, 0, 65535, cv2.NORM_MINMAX)

        ## Overlay ##

        #cv2.circle(a, (80, 60), 20, (255, 0, 255))
        ##
        np.right_shift(a, 8, a)
        time.sleep(0.02)
        return np.uint8(a)

    def Adq(self):
        global cvImg
        self.pushButton.setText('Adquiriendo')
        cvImg = self.capture()
        #print cvImg
        qImg = QImage(cvImg, 160, 120, QtGui.QImage.Format_Indexed8)
        self.label.setPixmap(QtGui.QPixmap.fromImage(qImg).scaled(qImg.width() * 2, qImg.height() * 2))
        # self.graph.plot(cvImg, clear=True)

    def Rec(self):
        print 'rec'
        global i, cvImg
        i += 1
        if not os.path.exists('./images'):
            os.makedirs('./images')
        ts = time.time()
        st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S.%f')
        name_img = './images/thermalseek_%d_%s.tiff' % (i, st)
        # tiff = TIFF.open(name_img, mode='w')
        # cvImg = cv2.resize(cvImg, 160, 120)
        # tiff.write_image(cvImg)
        time.sleep(1)
        cv2.imwrite(name_img, cvImg)

    def stop(self):
        global i
        i=0
        self.pushButton.setText('play')
        self.status = False
        self.timer.stop()
        self.timer2.stop()
        cv2.destroyAllWindows()

    def play(self):
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.Adq)
        self.timer.start(1000. / 20.)

    def RecStop(self, pressed):
        if pressed:
            print 'play'
            self.pushButton_3.setText('stop')
            self.timer2 = QtCore.QTimer()
            self.timer2.timeout.connect(self.Rec)
            self.timer2.start(1000. / 60)


app = QtGui.QApplication(sys.argv)
MyWindow = MyWindowClass(None)
MyWindow.show()
app.exec_()